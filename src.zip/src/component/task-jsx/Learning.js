const items = [
  {
    id: "1",
    date: "01 January 2021 ",
    task: "Learning",
    type: "doing",
  },
  {
    id: "2",
    date: "01 January 2021 ",
    task: "Learning",
    type: "Todo",
  },
  {
    id: "3",
    date: "01 January 2021 ",
    task: "Learning",
    type: "done",
  },
  {
    id: "4",
    date: "01 January 2021 ",
    task: "Learning",
    type: "done",
  },
];
export default items;
