const items = [
  {
    id: "1",
    date: "01 January 2021 ",
    task: "Personal",
    type: "doing",
  },
  {
    id: "2",
    date: "01 January 2021 ",
    task: "Personal",
    type: "Todo",
  },
  {
    id: "3",
    date: "01 January 2021 ",
    task: "Personal",
    type: "done",
  },
  {
    id: "4",
    date: "01 January 2021 ",
    task: "Personal",
    type: "done",
  },
];
export default items;
